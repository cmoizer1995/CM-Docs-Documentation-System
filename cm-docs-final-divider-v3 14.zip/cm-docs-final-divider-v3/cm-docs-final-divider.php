<?php
/**
 * Plugin Name: CM Docs Widget Final (Divider Titles)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ─────────────────────────────────────────
   Save the toggle — completely standalone,
   uses update_option directly, zero relation
   to options.php or register_setting
   ───────────────────────────────────────── */
add_action('admin_post_cm_docs_save_toggle', function() {
    check_admin_referer('cm_docs_toggle', 'cm_docs_toggle_nonce');
    if ( ! current_user_can('manage_options') ) wp_die('No permission');
    // Checkbox: present in POST = on, missing = off
    $val = ( isset($_POST['cm_docs_enabled_cb']) && $_POST['cm_docs_enabled_cb'] === '1' ) ? '1' : '0';
    update_option('cm_docs_enabled', $val);
    wp_redirect(admin_url('options-general.php?page=cm-docs-settings&saved=toggle'));
    exit;
});

/* ─────────────────────────────────────────
   Button colour save — own POST handler
   ───────────────────────────────────────── */
add_action('admin_post_cm_docs_save_buttons', function() {
    check_admin_referer('cm_docs_buttons', 'cm_docs_buttons_nonce');
    if ( ! current_user_can('manage_options') ) wp_die('No permission');
    if ( isset($_POST['cm_btn_bg']) )   update_option('cm_btn_bg',   sanitize_hex_color($_POST['cm_btn_bg']));
    if ( isset($_POST['cm_btn_text']) ) update_option('cm_btn_text', sanitize_hex_color($_POST['cm_btn_text']));
    wp_redirect(admin_url('options-general.php?page=cm-docs-settings&saved=buttons'));
    exit;
});

/* ─────────────────────────────────────────
   Post type saves via options.php as normal
   ───────────────────────────────────────── */
add_action('admin_init', function() {
    register_setting('cm_docs_settings_group', 'cm_docs_post_type');
});

/* ─────────────────────────────────────────
   Inject CSS on front-end to hide title when off
   ───────────────────────────────────────── */
add_action('wp_head', function() {
    if ( get_option('cm_docs_enabled', '1') !== '1' ) {
        echo '<style>#cm-docs-title { display: none !important; }</style>' . "\n";
    }
    $btn_bg   = get_option('cm_btn_bg',   '#211F40');
    $btn_text = get_option('cm_btn_text', '#ffffff');
    echo '<style>
.cm-btn,.cm-btn-primary,.cm-btn-secondary{background:'.esc_attr($btn_bg).'!important;color:'.esc_attr($btn_text).'!important}
.cm-btn:hover{background:'.esc_attr($btn_bg).'!important;color:'.esc_attr($btn_text).'!important}
</style>' . "\n";
});

/* SETTINGS PAGE */
add_action('admin_menu', function() {
    add_options_page('Docs Settings', 'Docs Settings', 'manage_options', 'cm-docs-settings', 'cm_docs_settings_page');
});

function cm_docs_settings_page() {
    $enabled = get_option('cm_docs_enabled', '1');
?>
<div class="wrap">
<h1>Documentation Settings</h1>

<?php if ( isset($_GET['saved']) ) : ?>
<div class="notice notice-success is-dismissible"><p>
<?php
if ( $_GET['saved'] === 'buttons' ) echo 'Button colours saved.';
else echo 'Title toggle saved.';
?>
</p></div>
<?php endif; ?>

<!-- Toggle posts to admin-post.php — completely separate from options.php -->
<h2>Title Visibility</h2>
<form method="post" action="<?php echo admin_url('admin-post.php'); ?>" id="cm-toggle-form">
    <input type="hidden" name="action" value="cm_docs_save_toggle">
    <input type="hidden" name="cm_docs_enabled_cb" id="cm-hidden-val" value="<?php echo $enabled==='1' ? '1' : ''; ?>">
    <?php wp_nonce_field('cm_docs_toggle', 'cm_docs_toggle_nonce'); ?>

    <table class="form-table">
    <tr>
    <th scope="row">Show Plugin Title</th>
    <td>
        <div style="display:inline-flex;align-items:center;gap:12px;">
            <span id="cm-track" onclick="cmDocsToggle()" style="
                position:relative;display:inline-block;
                width:46px;height:26px;border-radius:34px;
                background:<?php echo $enabled==='1' ? '#1d70b8' : '#ccc'; ?>;
                transition:.3s;cursor:pointer;flex-shrink:0;">
                <span id="cm-thumb" style="
                    position:absolute;top:3px;
                    left:<?php echo $enabled==='1' ? '23px' : '3px'; ?>;
                    width:20px;height:20px;border-radius:50%;
                    background:#fff;transition:.3s;">
                </span>
            </span>
            <span id="cm-lbl" style="font-weight:600;color:<?php echo $enabled==='1' ? '#1d70b8' : '#999'; ?>">
                <?php echo $enabled==='1' ? 'Enabled' : 'Disabled'; ?>
            </span>
        </div>
        <p class="description" style="margin-top:8px;">Show or hide the post title on the front-end.</p>
    </td>
    </tr>
    </table>

    <br>
    <input type="submit" class="button button-primary" value="Save Title Toggle">
</form>

<hr>

<h2>Button Style</h2>
<form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
    <input type="hidden" name="action" value="cm_docs_save_buttons">
    <?php wp_nonce_field('cm_docs_buttons', 'cm_docs_buttons_nonce'); ?>
    <table class="form-table">
    <tr>
    <th scope="row">Button Background</th>
    <td>
        <input type="color" name="cm_btn_bg" value="<?php echo esc_attr(get_option('cm_btn_bg','#211F40')); ?>"
               style="width:60px;height:36px;padding:2px;border:1px solid #ccc;border-radius:4px;cursor:pointer;">
        <span style="margin-left:8px;color:#666;font-size:13px;"><?php echo esc_html(get_option('cm_btn_bg','#211F40')); ?></span>
    </td>
    </tr>
    <tr>
    <th scope="row">Button Text Colour</th>
    <td>
        <input type="color" name="cm_btn_text" value="<?php echo esc_attr(get_option('cm_btn_text','#ffffff')); ?>"
               style="width:60px;height:36px;padding:2px;border:1px solid #ccc;border-radius:4px;cursor:pointer;">
        <span style="margin-left:8px;color:#666;font-size:13px;"><?php echo esc_html(get_option('cm_btn_text','#ffffff')); ?></span>
    </td>
    </tr>
    </table>
    <br>
    <input type="submit" class="button button-primary" value="Save Button Style">
</form>

<hr>

<h2>Post Type</h2>
<form method="post" action="options.php">
<?php settings_fields('cm_docs_settings_group'); ?>
<table class="form-table">
<tr>
<th scope="row">Select Post Type</th>
<td>
<select name="cm_docs_post_type">
<?php
$selected_pt = get_option('cm_docs_post_type', 'post');
$post_types  = get_post_types(['public' => true], 'objects');
foreach ($post_types as $pt) {
    echo '<option value="' . $pt->name . '" ' . selected($selected_pt, $pt->name, false) . '>' . $pt->labels->singular_name . '</option>';
}
?>
</select>
</td>
</tr>
</table>
<?php submit_button('Save Post Type'); ?>
</form>

</div>

<script>
var cmDocsOn = <?php echo $enabled==='1' ? 'true' : 'false'; ?>;
function cmDocsToggle() {
    cmDocsOn = !cmDocsOn;
    document.getElementById('cm-hidden-val').value = cmDocsOn ? '1' : '';
    document.getElementById('cm-track').style.background = cmDocsOn ? '#1d70b8' : '#ccc';
    document.getElementById('cm-thumb').style.left       = cmDocsOn ? '23px'    : '3px';
    document.getElementById('cm-lbl').textContent        = cmDocsOn ? 'Enabled' : 'Disabled';
    document.getElementById('cm-lbl').style.color        = cmDocsOn ? '#1d70b8' : '#999';
}
</script>
<?php
}

/* ACF */
add_action('acf/init', function(){
    if ( ! function_exists('acf_add_local_field_group') ) return;
    $post_type = get_option('cm_docs_post_type', 'post');
    acf_add_local_field_group(array(
        'key'   => 'group_docs',
        'title' => 'Project Documentation',
        'fields' => array(
            array('key'=>'field_desc','label'=>'Description','name'=>'description','type'=>'wysiwyg'),
            array('key'=>'field_download','label'=>'Download URL','name'=>'download_url','type'=>'url'),
            array('key'=>'field_demo','label'=>'Demo URL','name'=>'demo_url','type'=>'url'),
            array('key'=>'field_features','label'=>'Overview Features','name'=>'overview_features','type'=>'repeater',
                'sub_fields'=>array(
                    array('key'=>'field_ft_title','label'=>'Feature Title','name'=>'feature_title','type'=>'text'),
                    array('key'=>'field_ft_desc','label'=>'Feature Description','name'=>'feature_desc','type'=>'textarea'),
                ),
            ),
            array('key'=>'field_steps','label'=>'Steps','name'=>'steps','type'=>'repeater',
                'sub_fields'=>array(
                    array('key'=>'field_step_title','label'=>'Step Title','name'=>'step_title','type'=>'text'),
                    array('key'=>'field_step_desc','label'=>'Step Description','name'=>'step_desc','type'=>'textarea'),
                ),
            ),
            array('key'=>'field_tech','label'=>'Tech Stack','name'=>'tech_stack','type'=>'repeater',
                'sub_fields'=>array(
                    array('key'=>'field_tech_name','label'=>'Tech Name','name'=>'tech_name','type'=>'text'),
                ),
            ),
        ),
        'location' => array(array(array('param'=>'post_type','operator'=>'==','value'=>$post_type))),
    ));
});

/* WIDGET */
add_action('elementor/widgets/register', function($widgets_manager) {
    if ( ! did_action('elementor/loaded') ) return;

    class CM_Docs_Widget extends \Elementor\Widget_Base {

        public function get_name()       { return 'cm_docs_widget'; }
        public function get_title()      { return 'CM Documentation'; }
        public function get_icon()       { return 'eicon-post-list'; }
        public function get_categories() { return ['general']; }

        protected function register_controls() {

            $this->start_controls_section('general_section', ['label'=>'General','tab'=>\Elementor\Controls_Manager::TAB_CONTENT]);
            $this->add_control('title_toggle_info', [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw'  => '<p style="margin:0;color:#555;font-size:13px;">To show/hide the plugin title go to:<br><strong>WP Admin → Settings → Docs Settings</strong></p>',
            ]);
            $this->end_controls_section();

            $this->start_controls_section('style_section', ['label'=>'Style','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
            $this->add_control('primary_color', ['label'=>'Primary Color','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#1d70b8']);
            $this->add_control('card_bg',       ['label'=>'Card Background','type'=>\Elementor\Controls_Manager::COLOR,'default'=>'#f5f7fa']);
            $this->add_control('columns', [
                'label'   => 'Feature Columns',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => '2',
                'options' => ['1'=>'1','2'=>'2','3'=>'3'],
            ]);
            $this->end_controls_section();
        }

        protected function render() {
            $settings = $this->get_settings_for_display();

            echo '<style>
.cm-docs{max-width:100%;width:100%;margin:0 auto;font-family:-apple-system,system-ui;box-sizing:border-box}
.cm-header h2{font-size:28px;margin-bottom:10px}
.cm-desc{color:#555;line-height:1.5;margin-bottom:20px}
.cm-section-title{display:flex;align-items:center;text-align:center;font-size:18px;font-weight:600;margin:30px 0 20px;color:#333}
.cm-section-title:before,.cm-section-title:after{content:"";flex:1;border-bottom:1px solid #e3e6ea}
.cm-section-title:before{margin-right:12px}
.cm-section-title:after{margin-left:12px}
.cm-features{display:grid;gap:14px}
.cm-card{background:'.$settings['card_bg'].';padding:16px;border-radius:14px;border:1px solid #e3e6ea;transition:.2s}
.cm-card strong{display:block;font-size:16px;margin-bottom:6px}
.cm-card p{font-size:14px;color:#555;line-height:1.4}
.cm-card:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(0,0,0,.05)}
@media(max-width:767px){.cm-features{grid-template-columns:1fr!important}}
.cm-buttons{display:flex;flex-direction:column;gap:12px;margin-top:20px}@media(min-width:768px){.cm-buttons{flex-direction:row}.cm-btn{flex:1}}
.cm-btn{padding:14px 20px;border-radius:8px;text-decoration:none;font-weight:600;display:block;text-align:center;font-size:15px;color:#fff;background:#211F40;border:none}
.cm-btn:hover{color:#fff;background:#211F40;text-decoration:none}
.cm-btn-primary{background:#211F40}
.cm-btn-secondary{background:#211F40}
</style>';

            echo '<div class="cm-docs">';

            // h2 title wrapped in #cm-docs-title — CSS hides just this when toggle is off
            echo '<div id="cm-docs-title"><h2>' . get_the_title() . '</h2></div>';

            // Description always visible regardless of toggle
            if ( get_field('description') ) echo '<p class="cm-desc">' . get_field('description') . '</p>';

            if ( have_rows('overview_features') ) {
                echo '<h3 class="cm-section-title">Overview</h3>';
                echo '<div class="cm-features" style="grid-template-columns:repeat('.$settings['columns'].',1fr)">';
                while ( have_rows('overview_features') ) : the_row();
                    echo '<div class="cm-card"><strong>'.get_sub_field('feature_title').'</strong><p>'.get_sub_field('feature_desc').'</p></div>';
                endwhile;
                echo '</div>';
            }

            if ( have_rows('steps') ) {
                echo '<h3 class="cm-section-title">How It Works</h3>';
                echo '<div class="cm-features" style="grid-template-columns:repeat('.$settings['columns'].',1fr)">';
                while ( have_rows('steps') ) : the_row();
                    echo '<div class="cm-card"><strong>'.get_sub_field('step_title').'</strong><p>'.get_sub_field('step_desc').'</p></div>';
                endwhile;
                echo '</div>';
            }

            if ( have_rows('tech_stack') ) {
                echo '<h3 class="cm-section-title">Tech Stack</h3>';
                echo '<div class="cm-features" style="grid-template-columns:repeat('.$settings['columns'].',1fr)">';
                while ( have_rows('tech_stack') ) : the_row();
                    echo '<div class="cm-card"><strong>'.get_sub_field('tech_name').'</strong></div>';
                endwhile;
                echo '</div>';
            }

            // BUTTONS
            $post_id = get_the_ID();
            $download = function_exists('get_field') ? get_field('download_url', $post_id) : '';
            $demo     = function_exists('get_field') ? get_field('demo_url',     $post_id) : '';
            if ( $download || $demo ) {
                echo '<div class="cm-buttons">';
                if ( $download ) echo '<a href="' . esc_url($download) . '" class="cm-btn cm-btn-primary" target="_blank">Download</a>';
                if ( $demo )     echo '<a href="' . esc_url($demo)     . '" class="cm-btn cm-btn-secondary" target="_blank">Test</a>';
                echo '</div>';
            }

            echo '</div>';
        }
    }

    $widgets_manager->register(new CM_Docs_Widget());
});
